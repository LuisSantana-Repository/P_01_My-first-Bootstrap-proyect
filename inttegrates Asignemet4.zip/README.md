As a class for my web developting course, I was asked to make a webpage only using css, html and the bootstrap library.
